package com.example.luciano.chanchuno

/**
 * Created by luciano on 23/05/17.
 */
class Jugador(var nombre: String)
