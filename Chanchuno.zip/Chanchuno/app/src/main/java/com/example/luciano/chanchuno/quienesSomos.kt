package com.example.luciano.chanchuno

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

class quienesSomos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quienes_somos)
    }
}
