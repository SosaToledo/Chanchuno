Proyecto en android studio sobre un anotador de chancho va
